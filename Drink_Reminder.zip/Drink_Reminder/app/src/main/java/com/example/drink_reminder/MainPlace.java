package com.example.drink_reminder;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainPlace extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main_place);





    }

    public void onMyButtonClick(View view)
    {

        Toast.makeText(this, "Настройки завершены, можете закрыть приложение.", Toast.LENGTH_SHORT).show();

        Intent SecAct = new Intent(this, MyService.class);
        SecAct.putExtra(MyService.EXTRA_COUNT_TO, 5);




        Bundle extras = getIntent().getExtras();
        int firstHour = 0;
        int firstMinute = 0;

        int lastHour = 0;
        int lastMinutes = 0;

        int periodVremeni = 0;

        if (extras != null) {
            firstHour = extras.getInt("firstHours");
            firstMinute = extras.getInt("firstMinutes");

            lastHour = extras.getInt("lastHours");
            lastMinutes = extras.getInt("lastMinutes");

            periodVremeni = extras.getInt("periodVremeni");
        }


        SecAct.putExtra("firstHours", firstHour);
        SecAct.putExtra("firstMinutes", firstMinute);

        SecAct.putExtra("lastHours", lastHour);
        SecAct.putExtra("lastMinutes", lastMinutes);

        SecAct.putExtra("periodVremeni", periodVremeni);

        startService(SecAct);


    }

}












