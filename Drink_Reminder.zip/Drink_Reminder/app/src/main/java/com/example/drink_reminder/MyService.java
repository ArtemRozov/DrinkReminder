package com.example.drink_reminder;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import static android.content.ContentValues.TAG;

public class MyService extends Service {
    public static final String EXTRA_COUNT_TO = "count_to";

    private int countTo;
    private int currentNumber = 0;

    int firstHour = 0;
    int firstMinute = 0;

    int lastHour = 0;
    int lastMinutes = 0;

    int periodVremeni = 0;

    private int hours;
    private int minutes;

    public MyService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        firstHour = intent.getIntExtra("firstHours", 0);
        firstMinute = intent.getIntExtra("firstMinutes", 0);

        lastHour = intent.getIntExtra("lastHours", 0);
        lastMinutes = intent.getIntExtra("lastMinutes", 0);

        periodVremeni = intent.getIntExtra("periodVremeni", 0);

        Log.i(TAG, "MyService onStartCommand");
        readFlags(flags);
        MyRun mr = new MyRun(startId);
        new Thread(mr).start();

        return START_REDELIVER_INTENT;
    }

    void readFlags(int flags) {
        if ((flags&START_FLAG_REDELIVERY) == START_FLAG_REDELIVERY)
            Log.i(TAG, "START_FLAG_REDELIVERY");
        if ((flags&START_FLAG_RETRY) == START_FLAG_RETRY)
            Log.i(TAG, "START_FLAG_RETRY");
    }

    class MyRun implements Runnable {

        int startId;

        public MyRun(int startId) {
            this.startId = startId;
            Log.i(TAG, "MyRun#" + startId + " create");
        }

        public void run() {

            int specialTime = firstHour;
            int specialMinute = firstMinute;



            while(hours<=lastHour) {
                final Calendar calendar = Calendar.getInstance();
                hours = calendar.get(Calendar.HOUR_OF_DAY);
                minutes = calendar.get(Calendar.MINUTE);



                Log.i(TAG, "Current number: " + hours + ":" + minutes);
                Log.i(TAG, "Current number: " + firstHour + ":" + firstMinute);
                Log.i(TAG, "Current number: " + specialTime + ":" + specialMinute);

                if(hours == specialTime && minutes == specialMinute) {

                    Log.i(TAG, "Current number: " + (66));
                    showNotification();

                    Log.i(TAG, "Current number: " + (111));

                    specialTime += periodVremeni;
                }

                try {
                    TimeUnit.SECONDS.sleep(60);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                stop();
            }

            Log.i(TAG, "MyRun#" + startId + " start");

        }

        void stop() {
            Log.i(TAG, "MyRun#" + startId + " end, stopSelfResult("
                    + startId + ") = " + stopSelfResult(startId));
            Log.i(TAG, "Current number: " + (88));
        }
    }


private void showNotification(){
    Log.i(TAG, "Current number: " + (44));

    NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        @SuppressLint("WrongConstant") NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "My Notifications", NotificationManager.IMPORTANCE_MAX);

        // Configure the notification channel.
        notificationChannel.setDescription("Channel description");
        notificationChannel.enableLights(true);
        notificationChannel.setLightColor(Color.RED);
        notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
        notificationChannel.enableVibration(true);
        notificationManager.createNotificationChannel(notificationChannel);
    }


    NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);

    notificationBuilder.setAutoCancel(true)
            .setDefaults(Notification.DEFAULT_ALL)
            .setWhen(System.currentTimeMillis())
            .setSmallIcon(R.drawable.ic_water_not)
            .setTicker("Hearty365")
            //     .setPriority(Notification.PRIORITY_MAX)
            .setContentTitle("Нужно попить воды!")
            .setContentInfo("Info");

    notificationManager.notify(/*notification id*/1, notificationBuilder.build());


    }
}
