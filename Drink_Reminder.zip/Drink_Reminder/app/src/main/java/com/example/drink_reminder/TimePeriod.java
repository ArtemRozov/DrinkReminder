package com.example.drink_reminder;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TimePeriod extends Activity {

    private Button periodTime;
    private EditText period;
    public int periodVremeni;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.time_period);

        ButtonListener();
    }

    public void ButtonListener() {
        period = (EditText) findViewById(R.id.editText1);

        periodTime = (Button) findViewById(R.id.button_ready);
        periodTime.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //При нажатии кнопки запускается диалог TimePickerDialog для выбора времени:
                String vremennaya = null;


                if( !period.getText().toString().equals("") && period.getText().toString().length() > 0 )
                {
                    // Get String
                     vremennaya = period.getText().toString();
                    periodVremeni = Integer.parseInt(vremennaya);


                    Intent SecAct = new Intent(getApplicationContext(), MainPlace.class);

                    Bundle extras = getIntent().getExtras();
                    int firstHour = 0;
                    int firstMinute = 0;

                    int lastHour = 0;
                    int lastMinutes = 0;

                    if (extras != null) {
                        firstHour = extras.getInt("firstHours");
                        firstMinute = extras.getInt("firstMinutes");

                        lastHour = extras.getInt("lastHours");
                        lastMinutes = extras.getInt("lastMinutes");
                    }




                    SecAct.putExtra("firstHours", firstHour);
                    SecAct.putExtra("firstMinutes", firstMinute);

                    SecAct.putExtra("lastHours", lastHour);
                    SecAct.putExtra("lastMinutes", lastMinutes);

                    SecAct.putExtra("periodVremeni", periodVremeni);

                    startActivity(SecAct);
                } else {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Введите число", Toast.LENGTH_SHORT);
                    toast.show();
                }

            }
        });
    }

}
